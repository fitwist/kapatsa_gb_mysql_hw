USE vk;

SELECT 
	gender,
	COUNT(*)
FROM (
	SELECT
		user_id AS user,
		(
			SELECT gender
			FROM profiles 
			WHERE user_id = user
		) AS gender
	FROM likes
) as dummy
GROUP BY gender;
