USE vk;

SELECT *
FROM messages
WHERE to_user_id = 312
GROUP BY from_user_id
ORDER BY from_user_id DESC 
LIMIT 1;