SELECT 
	CASE(gender)
	    WHEN 'm' THEN 'Мужской'
	    WHEN 'f' THEN 'Женский'
	    ELSE 'nan'
	END as gender, COUNT(*) as 'Лайки поставили: ' 
FROM users GROUP BY gender;