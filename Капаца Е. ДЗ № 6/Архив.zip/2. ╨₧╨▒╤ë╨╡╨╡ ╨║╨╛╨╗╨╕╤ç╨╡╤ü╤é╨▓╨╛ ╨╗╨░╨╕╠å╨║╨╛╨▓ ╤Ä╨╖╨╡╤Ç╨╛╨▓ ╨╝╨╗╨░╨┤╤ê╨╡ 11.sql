USE vk;

SELECT COUNT(*) as 'children_likes' FROM users 
WHERE (YEAR(NOW()) - YEAR(birthday)) < 11;